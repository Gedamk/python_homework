import shutil

# Path to your assignment folder
folder_to_zip = "C:/Users/Gedan/Desktop/Python_homework/assignment8"

# Name of the zip file (without extension)
zip_file_name = "Python_Assignment8"

# Create the zip
shutil.make_archive(zip_file_name, 'zip', folder_to_zip)

print(f"Folder zipped successfully as {zip_file_name}.zip")
